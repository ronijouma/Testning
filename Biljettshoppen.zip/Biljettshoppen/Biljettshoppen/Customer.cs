﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biljettshoppen
{
    public class Customer
    {
        private string name;
        private string phonenumber;
        private string email;

        public Customer(string name, string email, string phonenumber)
        {
            Name = name;
            Phonenumber = phonenumber;
            Email = email;
        }

        public string Name
        { get { return name; } set { name = value; } }
        public string Phonenumber
        { get { return phonenumber; } set { phonenumber = value; } }
        public string Email
        { get { return email; } set { email = value; } }  
    }
}
