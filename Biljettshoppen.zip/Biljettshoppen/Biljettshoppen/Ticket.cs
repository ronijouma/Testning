﻿using Biljettshoppen.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biljettshoppen
{
    public class Ticket
    {
        public string EventName { get; set; }
        public DateTime EventDate { get; set; }
        public string Seat { get; set; }
        public decimal Price { get; set; }

        // Korrekt konstruktor
        public Ticket(string eventName, DateTime eventDate, string seat, decimal price)
        {
            EventName = eventName;
            EventDate = eventDate;
            Seat = seat;
            Price = price;
        }
    }
}
