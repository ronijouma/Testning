﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biljettshoppen.Events;
using Biljettshoppen.Interfaces;
using Biljettshoppen.Payment;

namespace Biljettshoppen
{
    public class Reservation
    {
        private Ocassion ocassion;
        private Customer customer;
        private List<int> bookedseats;
        PaymentStrategy paymentStrategy;
        PaymentFactory paymentFactory;
        private float timer;

        public Ocassion Ocassion { get { return ocassion; } set { ocassion = value; } }
        public Customer Customer { get { return customer; } set { customer = value; } }
        public List<int> Bookedseats { get { return bookedseats; } set { bookedseats = value; } }
        public float Timer { get { return timer; } set { timer = value; } }
        public List<Ticket> Tickets { get; set; }
        public DateTime Date { get; set; }

        public Reservation(List<Ticket> tickets, DateTime date, Customer customer)
        {
            Tickets = tickets;
            Date = date;
            Customer = customer;
        }

        public void DisplaySeatStatus(bool[,] reservations)
        {
            Console.WriteLine("Tillgängliga säten:");
            int rows = reservations.GetLength(0);
            int seatsPerRow = reservations.GetLength(1);

            for (int row = 0; row < rows; row++)
            {
                Console.WriteLine($"Rad {row + 1}:");

                for (int seat = 0; seat < seatsPerRow; seat++)
                {
                    Console.WriteLine($"Säte {seat + 1}: {(reservations[row, seat] ? "Reserverad" : "Tillgänglig")}");
                }

                Console.WriteLine();
            }
        }

        public void ReserveSeat(bool[,] reservations, int row, int seat)
        {
            int rows = reservations.GetLength(0);
            int seatsPerRow = reservations.GetLength(1);

            if (row > 0 && row <= rows && seat > 0 && seat <= seatsPerRow)
            {
                if (!reservations[row - 1, seat - 1])
                {
                    reservations[row - 1, seat - 1] = true;
                    Console.WriteLine($"Plats {row}-{seat} har blivit reserverad.");

                }
                else
                {
                    Console.WriteLine($"Plats {row}-{seat} är redan upptagen.");
                }
            }
            else
            {
                Console.WriteLine("Fel rad eller sätesnummer.");
            }
        }

        public void Pay()
        {
            paymentStrategy.Pay();
        }

        public void setPaymentStrategy()
        {
            string input = Console.ReadLine();
            paymentStrategy = paymentFactory.TypeOfPayment(input);
        }
    }
}
