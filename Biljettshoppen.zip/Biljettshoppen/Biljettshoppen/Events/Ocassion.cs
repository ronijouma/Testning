﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Biljettshoppen.Interfaces;

namespace Biljettshoppen.Events
{
    public class Ocassion : iOcassion
    {
        private PremiseFactory premiseFactory;
        private Premise premise;
        private string _ocassionName;
        private string _ocassionPerformer;
        private DateTime _ocassionDate;
        private string _ocassionType;
        

        public string OcassionName
        {
            get { return _ocassionName; }
            set { _ocassionName = value; }
        }
        public string OcassionPerformer
        {
            get { return _ocassionPerformer; }
            set { _ocassionPerformer = value; }
        }
        public DateTime OcassionDate
        {
            get { return _ocassionDate; }
            set { _ocassionDate = value; }
        }
        public Premise premiseSet
        {
            get { return premise; }
            set { premise = value; }
        }
        public PremiseFactory PremiseFactory
        {
            get { return premiseFactory; }
            set { premiseFactory = value; }
        }
        public string OcassionType
        {
            get { return _ocassionType; }
            set { _ocassionType = value; }
        }

        public Ocassion(string ocassionName, string ocassionPerformer, string ocassionType, DateTime ocassionDate, string typeOfPremise)
        {
            OcassionName = ocassionName;
            OcassionPerformer = ocassionPerformer;
            OcassionType = ocassionType;
            OcassionDate = ocassionDate;
            this.PremiseFactory = new PremiseFactory();
            premiseSet = premiseFactory.TypeOfPremise(typeOfPremise);

        }
    }
}
