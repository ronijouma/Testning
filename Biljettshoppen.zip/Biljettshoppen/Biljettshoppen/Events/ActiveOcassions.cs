﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biljettshoppen.Events
{
    public class ActiveOcassions
    {

        private List<Ocassion> ocassions; 

        public List<Ocassion> Ocassions
        { get { return ocassions; } set { ocassions = value; } }
        public ActiveOcassions()
        {
            ocassions = new List<Ocassion>(); 
        }
        public void AddOcassion(Ocassion ocassion)
        {
            Ocassions.Add(ocassion); 
        }
        public void PrintAllOcassions()
        {
            int number = 0;
            foreach (var concert in Ocassions)
            {

                Console.WriteLine("Concert:" + number);
                Console.WriteLine("Concert Name: " + concert.OcassionName);
                Console.WriteLine("Performer: " + concert.OcassionPerformer);
                Console.WriteLine("Concert Type: " + concert.OcassionType);
                Console.WriteLine("Date: " + concert.OcassionDate);
                Console.WriteLine("Premise Type: " + concert.premiseSet.GetLocation()); 
                Console.WriteLine();
                number++;
            }
        }
    }
}
